# Resources

- [Sprint by Google Venture](https://www.gv.com/sprint/)
- [The Design Sprint](https://www.thesprintbook.com/the-design-sprint)
- [Design Sprint Methodologies](https://designsprintkit.withgoogle.com/methodology/overview)

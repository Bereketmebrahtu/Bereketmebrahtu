These resources are helpful extra reading that may clarify or enhance concepts you're learning in the main curriculum.

- ### [Flex children examples](https://codepen.io/oliverjam/full/YzXYRzw)
  An explanation of how `flex-grow`, `flex-shrink` and `flex-basis` work for elements inside a flexbox container.

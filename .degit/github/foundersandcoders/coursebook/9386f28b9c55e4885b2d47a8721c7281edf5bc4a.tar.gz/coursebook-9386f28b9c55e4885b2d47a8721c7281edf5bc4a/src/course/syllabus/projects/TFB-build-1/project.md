# Project

This week is the first build sprint of your in-house project build.

Work through your sprint backlog, assigning user stories to members of the team.

# Spikes

There are no defined spikes for this week.

You may find that you need to manage spikes within your sprints. Remember to follow [the techniques you followed earlier in the programme](/course/handbook/spikes).

You're encouraged to continue role circles with those who are playing the same role as you.

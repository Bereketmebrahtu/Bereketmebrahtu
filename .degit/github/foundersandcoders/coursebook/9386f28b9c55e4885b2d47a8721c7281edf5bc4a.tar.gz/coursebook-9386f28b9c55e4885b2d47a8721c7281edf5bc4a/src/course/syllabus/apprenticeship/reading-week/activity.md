# Suggested activity for reading week

## Rest

Take an extended break from your screens.
Drink lots of water, stretch and sleep.

## Mentor

Start looking into opportunities to mentor others learning to code. [Codebar](https://codebar.io/coaches) is a great option.

## Revise

If you choose to do work during this period, we recommend you focus on [these resources](https://founders-and-coders.gitbook.io/coursebook/curriculum/reading-week/resources).

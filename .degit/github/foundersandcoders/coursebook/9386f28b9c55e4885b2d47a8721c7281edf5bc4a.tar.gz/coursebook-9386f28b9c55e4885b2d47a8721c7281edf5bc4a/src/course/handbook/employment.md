---
nav: false
---

# Employment schedule and material delivered in FAC20

## [The employment curriculum](https://hackmd.io/jY8pyE7iTWaThtkuUNgSjw)

### In pairs from previous project teams

- Week 4 GitHub
- [Week 5 Twitter](https://hackmd.io/Qb1vbesIS2enTaRUYdD09A)
- [Week 6 LinkedIn](https://hackmd.io/lLUSUXWZSTe47AwLHeNhMg)
- [Week 7 Employment mentor planning](https://hackmd.io/6S_2xAffSzuI7TQVT8yT8g)
- Reading week Employment mentor intro
- [Week 9 Portfolio site](https://hackmd.io/sK2PqWRvTmmAizCcuwhd2g)

### In React pairs

- [Week 10 CV & cover letter](https://hackmd.io/tWYq8d_2RViYsjOILsbLwA)

### With TfB team

- [Week 11 Job boards & recruiters (talent.io, Hired)](https://hackmd.io/hrHfx0hQQhmrZZe67BqC-Q)
- [Week 12 Developing a strategy](https://foundersandcoders.slack.com/files/UP8DS10P4/F01D30LFXV4/georgia_-_creating_a_job_hunting_strategy.pdf)
  - [Georgia's spreadsheet](https://docs.google.com/spreadsheets/d/1zGBd_5Qm4_-eogLjSGmTYWqreOUG8Gp9eNs6aXFM8sA/edit?usp=sharing)
- Week 13 Tools (Pramp, Leetcode) _everyone to arrange Pramp session_

### With student project team - _led by them and/or guest mentors_

- Week 14 Applications
- Week 15 Tech tests
- Week 16 Interview prep

### With week 1 team

- Week 17 Extracurricular skills
- Week 18 Data structures

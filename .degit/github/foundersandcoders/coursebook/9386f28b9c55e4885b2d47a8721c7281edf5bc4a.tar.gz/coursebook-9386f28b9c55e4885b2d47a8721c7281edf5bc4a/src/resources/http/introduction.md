---
title: HTTP introduction
---

HTTP is how the web works.

let dogs = {
  alphonso: { name: "Alphonso", breed: "German Shepherd" },
  lassie: { name: "Lassie", breed: "Golden Retriever" },
  pongo: { name: "Pongo", breed: "Dalmation" },
  luna: { name: "Luna", breed: "Cocker Spaniel" },
};

module.exports = dogs;

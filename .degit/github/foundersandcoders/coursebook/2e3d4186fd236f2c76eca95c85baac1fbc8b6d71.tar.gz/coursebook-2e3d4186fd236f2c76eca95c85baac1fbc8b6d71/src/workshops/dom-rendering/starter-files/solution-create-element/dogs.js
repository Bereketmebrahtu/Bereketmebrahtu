export default [
  {
    name: "sebastian",
    image: "https://placedog.net/500/300?id=1",
  },
  {
    name: "lucius",
    image: "https://placedog.net/500/300?id=2",
  },
  {
    name: "spot",
    image: "https://placedog.net/500/300?id=3",
  },
  {
    name: "belle",
    image: "https://placedog.net/500/300?id=4",
  },
  {
    name: "rover",
    image: "https://placedog.net/500/300?id=5",
  },
];

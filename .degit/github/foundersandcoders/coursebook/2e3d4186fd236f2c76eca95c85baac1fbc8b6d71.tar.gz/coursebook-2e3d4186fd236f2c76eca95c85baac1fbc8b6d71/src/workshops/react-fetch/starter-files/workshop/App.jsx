import React from "react";

function App() {
  return (
    <main>
      <div>GitHub user profile goes here</div>
    </main>
  );
}

export default App;

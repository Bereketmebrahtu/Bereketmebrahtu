These resources are helpful extra reading that may clarify or enhance concepts you're learning in the main curriculum.

- ### [JSON Web Tokens suck](https://www.youtube.com/watch?v=JdGOb7AxUo0)
  Despite the title this talk actually covers most aspects of web authentication in a very accessible way

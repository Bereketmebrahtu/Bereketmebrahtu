## Server-side app

- [ ] We can build a stable, professional app
- [ ] We can handle errors without our server crashing
- [ ] We can communicate problems to the user
- [ ] We can research and implement complex new features on our own

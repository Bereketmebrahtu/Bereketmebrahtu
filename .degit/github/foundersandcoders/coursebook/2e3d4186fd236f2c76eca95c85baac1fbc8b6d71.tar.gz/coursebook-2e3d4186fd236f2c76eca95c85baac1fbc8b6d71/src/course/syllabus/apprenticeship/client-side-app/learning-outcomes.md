## React

- [ ] We can explain what problems React solves
- [ ] We can explain when we might not use React
- [ ] We can use the React library to build apps
- [ ] We can use JSX to create DOM elements
- [ ] We can use function components to organise our code
- [ ] We can use component state to manage DOM updates
- [ ] We can manage side effects in our components
- [ ] We can re-write class components with the newer hooks API

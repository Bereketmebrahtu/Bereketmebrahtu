## Frontend Challenges

These are mostly HTML/CSS. Good to brush up on how to create a nice looking frontend.
https://piccalil.li/category/front-end%20challenges%20club/

## JavaScript 30

Great for JS/DOM basics whilst building some interesting small things. Scan the list of projects and pick a couple that sound interesting to you.
https://javascript30.com/

## Spikes

Revisit any of the Spike presentations you didn’t work on and read the original resources for them. They are intended to be a good overview of an interesting subject, and they will all be relevant in the second half.

---
title: Our course
---

This section of the site is intended for those currently attending our free web development bootcamp. If you're interested in applying you can find out more [on our main website](https://www.foundersandcoders.com/apply/).

If not you're welcome to use to learn at your own pace. Make sure you read [about the curriculum](/about/) to find out how you're allowed to use it.
